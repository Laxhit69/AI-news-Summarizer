document.getElementById("summarizeForm").addEventListener("submit", async function(event) {
    event.preventDefault();
    
    let textInput = document.getElementById("textInput").value;
    let summaryResult = document.getElementById("summaryResult");

    try {
        let response = await fetch("http://localhost:5000/summarize", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ text: textInput })
        });

        let data = await response.json();
        summaryResult.innerHTML = `<h3>Summary:</h3><p>${data.summary}</p>`;
    } catch (error) {
        console.error("Error:", error);
        summaryResult.innerHTML = "<p style='color: red;'>Failed to summarize. Try again!</p>";
    }
});
